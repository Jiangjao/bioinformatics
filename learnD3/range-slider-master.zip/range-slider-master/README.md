# Single/range slider plugin - pure JS
No dependencies required

![alt text](https://github.com/slawomir-zaziablo/range-slider/blob/master/demo.png)

Demo and usage: [DEMO](https://slawomir-zaziablo.github.io/range-slider/)
